--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
Please read this complete file carefully before working with the template
--------------------------------------------------------------------------------------------------

Created By: TANZIM AL DIN AHMED
Date: 19th April 2020, Sunday



--------------------------------------------------------------------------------------------------
Settings Files
--------------------------------------------------------------------------------------------------

** To Run the project, set the main.tex inside the root folder 
   as the main file of the project. **


Add Paper Information in the information.tex file inside the root folder.

Using \settitle{Paper Title}{Faculty}{Department}{Degree} command

1. Paper Title (example: Project Paperless)
2. Course Faculty (example: Electrical and Computer Engineering)
3. Course Department (example: Computer Science and Engineering)
4. Degree Name (example: Bachelor of Science)

Command Example: 

\settitle
{Project Paperless \\ Thesis Template}
{Electrical and Computer Engineering}
{Computer Science and Engineering}
{Bachelor of Science}


Add students into the students list using the 
addstudent[<number>]{<full_name>}{<student_id>} command

** Note that this list must be arranged row by row and column by column as it uses the tabular view.

Maximum 6 STUDENTS names are allowed. 
3 Rows, 2 Columns

Command Example: 
\studentslist{
    \addstudent[1]{Full Name}{Student ID} \nextcolumn
    \addstudent[2]{Full Name}{Student ID} \nextrow
    \addstudent[3]{Full Name}{Student ID} \nextcolumn
    \addstudent[4]{Full Name}{Student ID} \nextrow
    \addstudent[5]{Full Name}{Student ID} \nextcolumn
    \addstudent[6]{Full Name}{Student ID} \nextrow
}

Please refer to addstudent[<number>]{<full_name>}{<student_id>} command.


Add officers into the officers list using the approvedby{<officer_name>} command

Command Example:
\officerslist{
    \approvedby{Officer 1 Name}
    \approvedby{Officer 2 Name}
    \approvedby{Officer 3 Name}
    \approvedby{Officer 4 Name}
    \approvedby{Officer 5 Name}
    \approvedby{Officer 6 Name}
    \approvedby{Officer 7 Name}
    \approvedby{Officer 8 Name}
}

Pleased refer to approvedby{<officer_name>} command

--------------------------------------------------------------------------------------------------

Add new packages inside the main.tex inside the root folder

Packages available by default are:
babel [english]
fontenc [T1]
inputenc [utf8]
geometry
setspace
titlesec
xcolor
graphicx
tabularx
float

Example command to insert package:
\usepackage{graphicx}

--------------------------------------------------------------------------------------------------

Define custom macros inside the macros.tex file inside the root folder

--------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------
ADDING CHAPTERS
--------------------------------------------------------------------------------------------------

Add chapters inside the respective chapters folder with distinctive names.

It is recommended that separate folders are created for each chapter, for easier management, 
and then included in the main.tex file inside the root folder to link up with the document.

example: \inclue{<link_to_file>}

All the illustrations used in a particular chapter should also reside inside the
respective chapter folder.

--------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------
Adding Prologues
--------------------------------------------------------------------------------------------------

Prologues will show up in the front section of the document, before the main section.
Declaration, Approval and Abstract are mandatory.

Additional prologue files can be added into the prologues folder, and the filenames must also be
included in the main.tex inside the root folder to link up with the document.

example: \inclue{<link_to_file>}

Optional prologues files can also be removed if desired, and their respective include statements
must also be removed from the main.tex file.

--------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------
Available Macros
--------------------------------------------------------------------------------------------------

Tables can be created using the addtable command.
This creates Table with banded coloured rows with caption and label

\addtable{table styles}{
    Rows and Columns
}{Solar System Data table \cite{solarsystemdata}}{table_1}

Parameter 1: table column sytles (default latex syntax for tabular)
Parameter 2: table body
Parameter 3: caption text
Parameter 4: label

--------------------------------------------------------------------------------------------------

Images can be added using the illustration command.
This creates centered images with caption and label.

\illustration{<file_name>}{Caption Text}{Figure Label}

Parameter 1: filename
Parameter 2: caption text
Parameter 3: label

Optional  1: width

--------------------------------------------------------------------------------------------------

Students' names and initials can be added in the declaration page using the addstudent command.

\addstudent[1]{Full Name}{Student ID}

Parameter 1: Name
Parameter 2: ID
(Signature Image addition part is not completed)

Optional  1: Student Counter

--------------------------------------------------------------------------------------------------

Officers' names and initials can be added in the approval page suing the approvedby command.

\approvedby{Officer 1 Name}

Parameter 1: Name
(Signature Image addition part is not completed)

--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------